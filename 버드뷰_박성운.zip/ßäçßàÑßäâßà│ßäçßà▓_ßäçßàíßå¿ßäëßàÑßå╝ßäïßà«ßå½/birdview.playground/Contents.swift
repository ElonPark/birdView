import Foundation


func timePrint(with text: String) {
    
    let now = Date()
    let dateFormatter = DateFormatter()
    dateFormatter.dateFormat = "yyyy-MM-dd hh:mm:ss.SSSS" // 날짜 형식 설정
    let dateNow = dateFormatter.string(from: now)
    print("\(text) - \(dateNow)\n")
}

struct Couple {
    let person1: Int
    let person2: Int
    let matchHobbyCount: Int
}



func matchCount(_ person1: [String], and person2: [String]) -> Int {
    var h1 = [String : Bool]()
    var h2 = [String : Bool]()
    var intersection = [String]()

    for h in person1 {
        h1[h] = true
    }

    for h in person2 {
        let element = h1[h] ?? false
        let element2 = h2[h] ?? false

        if element && !element2 {
            intersection.append(h)
            h2[h] = true
        }
    }

    return intersection.count
    
//    //속도 개선을 위해 위에 로직으로 처리함
//    let p1 = Set(person1)
//    let p2 = Set(person2)
//    let intersection = p1.intersection(p2)
//
//    return intersection.count
}


func matchingCouple(with array: [String]) -> [Couple]{
    var couples = [Couple]()

    var couplesDic = [String : Bool]()
    var beforCount: Int = 0

    for (i, h1) in array.enumerated() {
        for (j, h2) in array.enumerated() {
            guard i != j else { continue }
            let isInclude = couplesDic["\(j)-\(i)"] ?? false
            guard !isInclude else { continue }

            let hobbys1 = h1.components(separatedBy: " ")
            let hobbys2 = h2.components(separatedBy: " ")
            
            let count = matchCount(hobbys1, and: hobbys2)
            
            if count > 0 {
                couplesDic["\(i)-\(j)"] = true
                
                if count >= beforCount {
                    beforCount = count
                    let couple = Couple(person1: i, person2: j, matchHobbyCount: count)

                    couples.append(couple)
                }
            }
        }
    }
    
    return couples
}

func printText(by couples: [Couple]) -> String {
    var printText: String = ""
    guard let maxCount = couples.first?.matchHobbyCount else { return printText }
    
    for couple in couples {
        guard couple.matchHobbyCount == maxCount else { break }
        
        let p1 = couple.person1 + 1
        let p2 = couple.person2 + 1
        
        if printText.isEmpty {
            printText = "\(p1)-\(p2)"
        } else {
            printText += ", \(p1)-\(p2)"
        }
    }
    
    return printText
}

func readTextFile(withName fileName: String) -> String {
    var text: String = ""
    let filePath = Bundle.main.path(forResource: fileName, ofType: "txt")
    
    guard let path = filePath else { return text }
    
    do {
        text = try String(contentsOfFile: path, encoding: .utf8)
    } catch {
        print(error.localizedDescription)
        
        return text
    }
 
    return text
}


// - MARK: main

func main() {
    let fileName = "버드뷰_500000x10"//"testdata"//
    let fileText = readTextFile(withName: fileName)
    
    guard !fileText.isEmpty else { return }
    
    let textArray = fileText.components(separatedBy: "\n")
    
    let couples = matchingCouple(with: textArray)

    let value = couples.sorted { $0.matchHobbyCount > $1.matchHobbyCount }
    
    let text = printText(by: value)
    
    print(text)
}


timePrint(with: "시작")
main()
timePrint(with: "\n종료")


